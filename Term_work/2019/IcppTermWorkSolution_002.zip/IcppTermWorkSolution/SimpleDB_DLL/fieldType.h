#ifndef FIELD_TYPE_H
#define FIELD_TYPE_H

// Typ datov�ho pole
enum struct FieldType {
	Integer,
	Double,
	String,
	Field
};

#endif
